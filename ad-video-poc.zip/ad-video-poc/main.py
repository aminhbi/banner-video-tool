#!/usr/bin/env python3
"""Banner -> short animated ad video (proof of concept).

Usage:
    python3 main.py --input banner.png --output output/out.mp4 \\
        --duration 5 --width 1920 --height 1080

Pipeline: OCR text detection -> saliency-based subject/logo cutout ->
inpaint a clean background plate -> render a parallax Ken-Burns +
motion-graphics text reveal -> encode with ffmpeg.
"""
import argparse
import sys
import time
import cv2

from banner_animator.compose import build_layers
from banner_animator.animate import render_frames
from banner_animator.render import encode_video


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", required=True, help="path to the source banner image (PNG/JPG)")
    ap.add_argument("--output", default="output/out.mp4", help="output mp4 path")
    ap.add_argument("--duration", type=float, default=5.0, help="clip length in seconds (4-6 recommended)")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--width", type=int, default=1920, help="output canvas width")
    ap.add_argument("--height", type=int, default=1080, help="output canvas height")
    ap.add_argument("--min-conf", type=float, default=40.0,
                     help="OCR confidence threshold (0-100). Low-confidence boxes are still "
                          "kept if they visibly contain ink, so this mainly tunes false-positive risk.")
    ap.add_argument("--direction", choices=["rtl", "ltr"], default="rtl",
                     help="reading direction for staggering multiple text lines on the same row "
                          "(rtl = Persian/Arabic default, ltr = Latin)")
    ap.add_argument("--debug-layers", action="store_true", help="also dump the detected layers as images for inspection")
    args = ap.parse_args()

    banner = cv2.imread(args.input, cv2.IMREAD_COLOR)
    if banner is None:
        sys.exit(f"could not read image: {args.input}")

    t0 = time.time()
    layers = build_layers(banner, min_conf=args.min_conf, direction=args.direction)
    t1 = time.time()
    print(f"[1/2] detected {len(layers['texts'])} text line(s), "
          f"subject box={layers['subject'].x, layers['subject'].y, layers['subject'].w, layers['subject'].h}, "
          f"logo={'yes' if layers['logo'] else 'no'}  ({t1 - t0:.1f}s)")

    if args.debug_layers:
        import os
        dbg_dir = "frames/_debug"
        os.makedirs(dbg_dir, exist_ok=True)
        cv2.imwrite(f"{dbg_dir}/plate.png", layers["plate"])
        cv2.imwrite(f"{dbg_dir}/subject.png", layers["subject"].rgba)
        if layers["logo"]:
            cv2.imwrite(f"{dbg_dir}/logo.png", layers["logo"].rgba)
        for i, l in enumerate(layers["texts"]):
            cv2.imwrite(f"{dbg_dir}/text_{i}.png", l.rgba)
        print(f"      debug layer images written to {dbg_dir}/")

    frames = render_frames(layers, args.width, args.height, args.duration, args.fps)
    n = encode_video(frames, args.width, args.height, args.fps, args.output)
    t2 = time.time()
    print(f"[2/2] encoded {n} frames -> {args.output}  ({t2 - t1:.1f}s)")


if __name__ == "__main__":
    main()
