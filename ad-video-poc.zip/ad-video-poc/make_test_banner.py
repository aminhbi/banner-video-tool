#!/usr/bin/env python3
"""Generate a synthetic ad banner (gradient background, a 'product'
blob, a headline, a subline, and a small corner 'logo') purely with
Pillow, so we have something to test the pipeline on before a real
banner is supplied."""
from PIL import Image, ImageDraw, ImageFont
import numpy as np

W, H = 1200, 628  # common FB/LinkedIn link-ad banner size


def gradient_bg(w, h, c1, c2):
    base = np.zeros((h, w, 3), np.uint8)
    for y in range(h):
        t = y / (h - 1)
        color = tuple(int(c1[i] * (1 - t) + c2[i] * t) for i in range(3))
        base[y, :] = color
    return Image.fromarray(base)


def font(size, bold=True):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for c in candidates:
        try:
            return ImageFont.truetype(c, size)
        except OSError:
            continue
    return ImageFont.load_default()


def main():
    img = gradient_bg(W, H, (25, 40, 95), (10, 15, 35))
    draw = ImageDraw.Draw(img)

    # "product": a rounded-rect card with a circle on it, sitting right-of-center
    prod_x, prod_y, prod_w, prod_h = 700, 140, 380, 380
    draw.rounded_rectangle([prod_x, prod_y, prod_x + prod_w, prod_y + prod_h],
                            radius=40, fill=(240, 200, 60))
    draw.ellipse([prod_x + 60, prod_y + 60, prod_x + prod_w - 60, prod_y + prod_h - 60],
                  fill=(230, 90, 60))

    # headline + subline (left side)
    draw.text((70, 160), "SUMMER SALE", font=font(64), fill=(255, 255, 255))
    draw.text((70, 240), "Up to 50% Off", font=font(46), fill=(255, 210, 90))
    draw.text((70, 310), "Shop the new collection today", font=font(30, bold=False), fill=(220, 220, 230))

    # corner logo (small circle + letter, top-left)
    draw.ellipse([40, 40, 110, 110], fill=(255, 255, 255))
    draw.text((60, 52), "N", font=font(36), fill=(25, 40, 95))

    # CTA text bottom-left
    draw.rounded_rectangle([70, 500, 260, 560], radius=10, fill=(255, 210, 90))
    draw.text((100, 512), "SHOP NOW", font=font(28), fill=(25, 40, 95))

    img.save("assets/test_banner.png")
    print("wrote assets/test_banner.png", img.size)


if __name__ == "__main__":
    main()
