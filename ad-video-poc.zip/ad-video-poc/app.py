#!/usr/bin/env python3
"""Small internal web app around the banner-to-video pipeline, so
teammates without CLI/Claude access can upload a banner and get an
animated video back through a browser.

Run directly:   python3 app.py                (dev server, port 5000)
Run in Docker:  see Dockerfile / docker-compose.yml
"""
import os
import time
import uuid
import traceback

import cv2
from flask import (Flask, request, render_template, send_from_directory,
                    redirect, url_for, abort)
from werkzeug.utils import secure_filename

from banner_animator.compose import build_layers
from banner_animator.animate import render_frames
from banner_animator.render import encode_video

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "data", "uploads")
OUTPUT_DIR = os.path.join(BASE_DIR, "data", "outputs")
ALLOWED_EXT = {"png", "jpg", "jpeg", "webp"}
MAX_AGE_SECONDS = 24 * 3600  # auto-cleanup jobs older than this on each request

ASPECT_PRESETS = {
    "16:9": (1920, 1080),
    "9:16": (1080, 1920),
    "1:1": (1080, 1080),
    "4:5": (1080, 1350),
}

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024  # 20 MB uploads


def _allowed(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT


def _cleanup_old_jobs():
    now = time.time()
    for root in (UPLOAD_DIR, OUTPUT_DIR):
        try:
            for name in os.listdir(root):
                path = os.path.join(root, name)
                try:
                    if now - os.path.getmtime(path) > MAX_AGE_SECONDS:
                        for f in os.listdir(path):
                            os.remove(os.path.join(path, f))
                        os.rmdir(path)
                except OSError:
                    continue
        except FileNotFoundError:
            continue


@app.route("/")
def index():
    _cleanup_old_jobs()
    return render_template("index.html", aspects=list(ASPECT_PRESETS.keys()))


@app.route("/generate", methods=["POST"])
def generate():
    file = request.files.get("banner")
    if file is None or file.filename == "":
        return render_template("index.html", aspects=list(ASPECT_PRESETS.keys()),
                                error="لطفاً یک فایل بنر (PNG/JPG) انتخاب کنید.")
    if not _allowed(file.filename):
        return render_template("index.html", aspects=list(ASPECT_PRESETS.keys()),
                                error="فرمت فایل پشتیبانی نمی‌شود. PNG، JPG یا WEBP آپلود کنید.")

    aspect = request.form.get("aspect", "16:9")
    width, height = ASPECT_PRESETS.get(aspect, (1920, 1080))
    try:
        duration = float(request.form.get("duration", 5.0))
    except ValueError:
        duration = 5.0
    duration = max(3.0, min(8.0, duration))
    direction = request.form.get("direction", "rtl")
    if direction not in ("rtl", "ltr"):
        direction = "rtl"

    job_id = uuid.uuid4().hex[:12]
    job_upload_dir = os.path.join(UPLOAD_DIR, job_id)
    job_output_dir = os.path.join(OUTPUT_DIR, job_id)
    os.makedirs(job_upload_dir, exist_ok=True)
    os.makedirs(job_output_dir, exist_ok=True)

    ext = secure_filename(file.filename).rsplit(".", 1)[1].lower()
    input_path = os.path.join(job_upload_dir, f"input.{ext}")
    file.save(input_path)

    output_path = os.path.join(job_output_dir, "video.mp4")

    try:
        banner = cv2.imread(input_path, cv2.IMREAD_COLOR)
        if banner is None:
            raise ValueError("فایل تصویر خوانده نشد؛ فرمت را بررسی کنید.")
        layers = build_layers(banner, min_conf=40.0, direction=direction)
        frames = render_frames(layers, width, height, duration, fps=30)
        encode_video(frames, width, height, fps=30, out_path=output_path)
    except Exception as e:
        traceback.print_exc()
        return render_template("index.html", aspects=list(ASPECT_PRESETS.keys()),
                                error=f"پردازش بنر با خطا مواجه شد: {e}")

    return redirect(url_for("result", job_id=job_id))


@app.route("/result/<job_id>")
def result(job_id):
    video_path = os.path.join(OUTPUT_DIR, job_id, "video.mp4")
    if not os.path.isfile(video_path):
        abort(404)
    return render_template("result.html", job_id=job_id)


@app.route("/media/<job_id>/video.mp4")
def media(job_id):
    job_dir = os.path.join(OUTPUT_DIR, job_id)
    if not os.path.isfile(os.path.join(job_dir, "video.mp4")):
        abort(404)
    return send_from_directory(job_dir, "video.mp4", mimetype="video/mp4")


@app.route("/healthz")
def healthz():
    return {"status": "ok"}


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, threaded=True)
