"""Pipe rendered BGR frames straight into ffmpeg (no PNG sequence on
disk) and encode an H.264 MP4."""
import subprocess


def encode_video(frame_iter, canvas_w, canvas_h, fps, out_path, crf=18, preset="medium"):
    cmd = [
        "ffmpeg", "-y",
        "-f", "rawvideo", "-vcodec", "rawvideo",
        "-pix_fmt", "bgr24", "-s", f"{canvas_w}x{canvas_h}", "-r", str(fps),
        "-i", "-",
        "-an",
        "-vcodec", "libx264", "-pix_fmt", "yuv420p",
        "-crf", str(crf), "-preset", preset,
        "-movflags", "+faststart",
        out_path,
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    n = 0
    for frame in frame_iter:
        assert frame.shape[1] == canvas_w and frame.shape[0] == canvas_h, \
            f"frame size {frame.shape} != {(canvas_h, canvas_w)}"
        proc.stdin.write(frame.tobytes())
        n += 1
    proc.stdin.close()
    stderr = proc.stderr.read()
    proc.wait()
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg failed (exit {proc.returncode}):\n{stderr.decode(errors='ignore')[-3000:]}")
    return n
