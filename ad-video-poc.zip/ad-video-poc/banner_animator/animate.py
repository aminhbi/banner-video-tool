"""Per-frame renderer: takes the layer stack from compose.build_layers()
and produces a sequence of BGR frames at a target 16:9 (or custom)
resolution.

Motion design (kept deliberately simple / readable, tweak the
constants below to taste):

  background (plate) - slow Ken-Burns zoom-in + small diagonal pan.
  subject/product     - pops in with an ease-out-back scale, then
                        keeps growing a little faster than the
                        background (parallax: "near" layer moves
                        more) plus a gentle continuous float.
  text lines          - fade + slide-up, staggered one after another
                        in reading order, then hold steady so the
                        copy stays legible.
  logo                - quick fade + tiny scale-in near the start.

Everything outside the banner's own aspect ratio (when the target
canvas is a different shape, e.g. a square banner rendered to 16:9)
is filled with a softly blurred, zoomed-in copy of the background so
there are no hard black bars.
"""
import math
import numpy as np
import cv2

from .easing import clamp, ease_out_cubic, ease_in_out_cubic, ease_out_back, lerp
from .compose import Sprite

# ---- tunable motion constants -------------------------------------------------
BG_ZOOM_END = 0.93          # visible fraction of the plate at the end (zoom-in)
BG_PAN = 0.025              # fractional pan of the center point
SUBJECT_ENTRANCE_FRAC = 0.28    # portion of duration spent on the pop-in
SUBJECT_START_SCALE = 0.82
SUBJECT_END_GROWTH = 1.10       # extra growth over the whole clip (parallax)
SUBJECT_FLOAT_AMPL = 0.012      # fraction of banner height
SUBJECT_FLOAT_HZ = 0.6
TEXT_ENTRANCE_FRAC = 0.30
TEXT_STAGGER_FRAC = 0.10
TEXT_BASE_DELAY_FRAC = 0.06
TEXT_SLIDE_PX_FRAC = 0.05       # fraction of banner height
LOGO_ENTRANCE_FRAC = 0.22


def _resize_rgba(rgba, new_w, new_h):
    new_w, new_h = max(1, int(new_w)), max(1, int(new_h))
    interp = cv2.INTER_AREA if new_w < rgba.shape[1] else cv2.INTER_CUBIC
    return cv2.resize(rgba, (new_w, new_h), interpolation=interp)


def alpha_paste(canvas_bgr, sprite: Sprite, center_x, center_y, scale=1.0, opacity=1.0, extra_dy=0.0):
    if opacity <= 0.001:
        return
    h0, w0 = sprite.rgba.shape[:2]
    rgba = _resize_rgba(sprite.rgba, w0 * scale, h0 * scale)
    sh, sw = rgba.shape[:2]

    top_left_x = int(round(center_x - sw / 2))
    top_left_y = int(round(center_y - sh / 2 + extra_dy))

    ch, cw = canvas_bgr.shape[:2]
    x1, y1 = top_left_x, top_left_y
    x2, y2 = x1 + sw, y1 + sh

    sx1, sy1 = 0, 0
    sx2, sy2 = sw, sh
    if x1 < 0:
        sx1 = -x1; x1 = 0
    if y1 < 0:
        sy1 = -y1; y1 = 0
    if x2 > cw:
        sx2 -= (x2 - cw); x2 = cw
    if y2 > ch:
        sy2 -= (y2 - ch); y2 = ch
    if x2 <= x1 or y2 <= y1:
        return

    patch = rgba[sy1:sy2, sx1:sx2]
    alpha = (patch[:, :, 3:4].astype(np.float32) / 255.0) * opacity
    fg = patch[:, :, :3].astype(np.float32)
    bg = canvas_bgr[y1:y2, x1:x2].astype(np.float32)
    blended = fg * alpha + bg * (1 - alpha)
    canvas_bgr[y1:y2, x1:x2] = blended.astype(np.uint8)


def _bg_crop_frame(plate, t):
    h, w = plate.shape[:2]
    frac = lerp(1.0, BG_ZOOM_END, ease_in_out_cubic(t))
    crop_w, crop_h = w * frac, h * frac
    cx = w * (0.5 + BG_PAN * ease_in_out_cubic(t))
    cy = h * (0.5 + BG_PAN * 0.6 * ease_in_out_cubic(t))
    x1 = clamp(cx - crop_w / 2, 0, w - crop_w)
    y1 = clamp(cy - crop_h / 2, 0, h - crop_h)
    x1i, y1i = int(round(x1)), int(round(y1))
    x2i, y2i = int(round(x1 + crop_w)), int(round(y1 + crop_h))
    crop = plate[y1i:y2i, x1i:x2i]
    return cv2.resize(crop, (w, h), interpolation=cv2.INTER_CUBIC)


def render_banner_frame(layers, t):
    """Composite one frame at the banner's native (w, h) resolution."""
    w, h = layers["size"]
    frame = _bg_crop_frame(layers["plate"], t).copy()

    # --- subject / product -------------------------------------------------
    subj: Sprite = layers["subject"]
    entrance_t = clamp(t / max(1e-6, SUBJECT_ENTRANCE_FRAC))
    pop_scale = lerp(SUBJECT_START_SCALE, 1.0, ease_out_back(entrance_t))
    growth = lerp(1.0, SUBJECT_END_GROWTH, ease_in_out_cubic(t))
    float_dy = SUBJECT_FLOAT_AMPL * h * math.sin(2 * math.pi * SUBJECT_FLOAT_HZ * t) * clamp(entrance_t)
    subj_scale = pop_scale * growth
    subj_opacity = clamp(entrance_t / 0.4) if entrance_t < 1 else 1.0
    subj_cx = subj.x + subj.w / 2
    subj_cy = subj.y + subj.h / 2
    alpha_paste(frame, subj, subj_cx, subj_cy, scale=subj_scale, opacity=subj_opacity, extra_dy=float_dy)

    # --- text lines, staggered -----------------------------------------------
    for i, line in enumerate(layers["texts"]):
        delay = TEXT_BASE_DELAY_FRAC + i * TEXT_STAGGER_FRAC
        local_t = clamp((t - delay) / max(1e-6, TEXT_ENTRANCE_FRAC))
        if local_t <= 0:
            continue
        eased = ease_out_cubic(local_t)
        opacity = eased
        slide = (1 - eased) * TEXT_SLIDE_PX_FRAC * h
        cx = line.x + line.w / 2
        cy = line.y + line.h / 2
        alpha_paste(frame, line, cx, cy, scale=1.0, opacity=opacity, extra_dy=slide)

    # --- logo ------------------------------------------------------------------
    logo = layers.get("logo")
    if logo is not None:
        local_t = clamp(t / LOGO_ENTRANCE_FRAC)
        eased = ease_out_back(local_t)
        opacity = clamp(local_t / 0.5) if local_t < 1 else 1.0
        cx = logo.x + logo.w / 2
        cy = logo.y + logo.h / 2
        alpha_paste(frame, logo, cx, cy, scale=lerp(0.7, 1.0, eased), opacity=opacity)

    return frame


def _cover_backdrop(plate, canvas_w, canvas_h):
    h, w = plate.shape[:2]
    scale = max(canvas_w / w, canvas_h / h) * 1.08
    big = cv2.resize(plate, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_CUBIC)
    bh, bw = big.shape[:2]
    x1 = (bw - canvas_w) // 2
    y1 = (bh - canvas_h) // 2
    crop = big[y1:y1 + canvas_h, x1:x1 + canvas_w]
    crop = cv2.GaussianBlur(crop, (0, 0), sigmaX=canvas_w * 0.02)
    crop = (crop.astype(np.float32) * 0.55).astype(np.uint8)  # darken so foreground pops
    return crop


def render_frames(layers, canvas_w, canvas_h, duration_sec, fps):
    w, h = layers["size"]
    banner_aspect = w / h
    canvas_aspect = canvas_w / canvas_h
    needs_backdrop = abs(banner_aspect - canvas_aspect) > 0.02

    backdrop = _cover_backdrop(layers["plate"], canvas_w, canvas_h) if needs_backdrop else None

    if banner_aspect > canvas_aspect:
        content_w = canvas_w
        content_h = int(round(canvas_w / banner_aspect))
    else:
        content_h = canvas_h
        content_w = int(round(canvas_h * banner_aspect))
    off_x = (canvas_w - content_w) // 2
    off_y = (canvas_h - content_h) // 2

    n_frames = max(1, int(round(duration_sec * fps)))
    for i in range(n_frames):
        t = i / max(1, n_frames - 1)
        banner_frame = render_banner_frame(layers, t)

        if backdrop is None and content_w == canvas_w and content_h == canvas_h:
            yield cv2.resize(banner_frame, (canvas_w, canvas_h), interpolation=cv2.INTER_CUBIC)
            continue

        canvas = backdrop.copy() if backdrop is not None else np.zeros((canvas_h, canvas_w, 3), np.uint8)
        content = cv2.resize(banner_frame, (content_w, content_h), interpolation=cv2.INTER_CUBIC)
        canvas[off_y:off_y + content_h, off_x:off_x + content_w] = content
        yield canvas
