"""Foreground/product (and optional logo) segmentation using classical CV.

No neural nets, no model downloads -- this environment has no outbound
access to model hubs. Two signals are combined to guess which pixels
are "the ad content" (product/hero art + logo mark) as opposed to
"the background":

  1. Color-distance-from-background. Ad banners are usually a flat or
     gently-gradient background behind a product cutout/photo, so we
     sample the color statistics along the image border (a reliable
     background patch on almost every banner), and flag any pixel far
     from that distribution in Lab space as foreground. This is what
     actually finds large, flat-colored product graphics -- the case
     a generic saliency detector tends to miss, because spectral
     saliency favors small high-frequency blobs over big flat ones.
  2. Spectral-residual saliency (Hou & Zhang), used only as a fallback
     when the border sample says the background itself is *not* flat
     (e.g. a busy photographic background), where the color-distance
     signal isn't meaningful.

Whichever mask wins, the largest qualifying connected component is
taken as the "subject" (near layer) and refined with GrabCut for a
soft silhouette; a smaller component tucked in a corner is offered up
as an optional "logo".

This foreground/background split is also the "depth" proxy behind the
parallax illusion later: subject = near layer (moves/scales more),
background = far layer (moves less). It is not real monocular depth
estimation, but it is enough to sell a 2.5D camera move for a POC.
"""
import numpy as np
import cv2

# background is considered "flat enough" for color-distance segmentation
# when the per-channel std-dev of border samples (in Lab space) is below this.
FLAT_BG_STD_THRESHOLD = 20.0
FG_COLOR_Z_THRESHOLD = 3.0


def _spectral_residual_saliency(image_bgr: np.ndarray, work_size: int = 64) -> np.ndarray:
    """Manual implementation of Hou & Zhang's spectral-residual saliency
    (the same algorithm cv2.saliency.StaticSaliencySpectralResidual
    wraps). This build of opencv-contrib ships an empty `cv2.saliency`
    module (no compiled bindings), so we compute it directly with
    numpy's FFT instead of depending on that contrib module."""
    h, w = image_bgr.shape[:2]
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32)
    small = cv2.resize(gray, (work_size, work_size), interpolation=cv2.INTER_AREA)

    f = np.fft.fft2(small)
    amplitude = np.abs(f)
    phase = np.angle(f)
    log_amp = np.log(amplitude + 1e-8)
    avg_log_amp = cv2.blur(log_amp, (3, 3))
    spectral_residual = log_amp - avg_log_amp

    reconstructed = np.exp(spectral_residual) * np.exp(1j * phase)
    sal = np.abs(np.fft.ifft2(reconstructed)) ** 2
    sal = cv2.GaussianBlur(sal, (9, 9), 2.5)
    sal = cv2.resize(sal, (w, h), interpolation=cv2.INTER_CUBIC)
    return sal.astype(np.float32)


def _saliency_foreground_mask(image_bgr: np.ndarray) -> np.ndarray:
    try:
        sal_map = _spectral_residual_saliency(image_bgr)
        if not np.isfinite(sal_map).all() or sal_map.max() - sal_map.min() < 1e-6:
            raise ValueError("degenerate saliency map")
    except Exception:
        gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
        gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0)
        gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1)
        sal_map = cv2.GaussianBlur(cv2.magnitude(gx, gy), (15, 15), 0)
    sal_map = cv2.normalize(sal_map, None, 0, 1, cv2.NORM_MINMAX)
    thresh = max(0.35, float(np.percentile(sal_map, 90)))
    return (sal_map >= thresh).astype(np.uint8) * 255


def _border_background_stats(lab: np.ndarray, exclude_mask, border_frac=0.035):
    """Robust (median/MAD, not mean/std) background color estimate from
    the image border. Robust statistics matter here: on a "bleed" style
    banner where the hero photo runs to the edge (very common), the
    border ring itself is partly foreground pixels, and a plain mean/std
    gets dragged badly off by that minority -- median/MAD shrugs it off
    as long as background pixels are still the majority of the ring."""
    h, w = lab.shape[:2]
    bm = max(3, int(min(h, w) * border_frac))
    border = np.zeros((h, w), np.uint8)
    border[:bm, :] = 1
    border[-bm:, :] = 1
    border[:, :bm] = 1
    border[:, -bm:] = 1
    if exclude_mask is not None:
        border[exclude_mask > 0] = 0
    ys, xs = np.where(border > 0)
    if len(ys) < 20:
        return None
    samples = lab[ys, xs]
    median = np.median(samples, axis=0)
    mad = np.median(np.abs(samples - median), axis=0) * 1.4826  # ~ std-equivalent
    return median, mad


def _color_distance_foreground_mask(image_bgr: np.ndarray, exclude_mask):
    """Returns (mask or None, is_flat_background). None means the
    background doesn't look flat enough for this method to be meaningful."""
    lab = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
    stats = _border_background_stats(lab, exclude_mask)
    if stats is None:
        return None, False
    mean, std = stats
    if float(np.mean(std)) > FLAT_BG_STD_THRESHOLD:
        return None, False
    std = np.maximum(std, 2.0)
    z = np.sqrt((((lab - mean) / std) ** 2).sum(axis=2))
    mask = (z > FG_COLOR_Z_THRESHOLD).astype(np.uint8) * 255
    return mask, True


def _foreground_mask(image_bgr: np.ndarray, exclude_mask=None) -> np.ndarray:
    color_mask, is_flat = _color_distance_foreground_mask(image_bgr, exclude_mask)
    mask = color_mask if is_flat else _saliency_foreground_mask(image_bgr)
    if exclude_mask is not None:
        mask[exclude_mask > 0] = 0
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((21, 21), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
    return mask


def _components_by_area(mask: np.ndarray, min_area_frac: float, max_area_frac: float):
    h, w = mask.shape[:2]
    n, labels, stats, centroids = cv2.connectedComponentsWithStats(mask, connectivity=8)
    comps = []
    for i in range(1, n):  # skip background label 0
        area = stats[i, cv2.CC_STAT_AREA]
        if area < min_area_frac * h * w or area > max_area_frac * h * w:
            continue
        x, y, bw, bh = (stats[i, cv2.CC_STAT_LEFT], stats[i, cv2.CC_STAT_TOP],
                         stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT])
        comps.append({"bbox": (x, y, bw, bh), "area": area, "centroid": centroids[i]})
    return comps


def find_subject_bbox(image_bgr: np.ndarray, exclude_mask: np.ndarray | None = None):
    """Find the bounding box of the main subject/product.

    exclude_mask: optional 0/255 mask of pixels to ignore (e.g. text),
    so headline text doesn't get mistaken for the "subject".
    """
    h, w = image_bgr.shape[:2]
    mask = _foreground_mask(image_bgr, exclude_mask)
    comps = _components_by_area(mask, min_area_frac=0.01, max_area_frac=0.85)
    if not comps:
        # Nothing qualifies -- treat the central 55% of the banner as the subject.
        cx1, cy1 = int(w * 0.225), int(h * 0.225)
        cx2, cy2 = int(w * 0.775), int(h * 0.775)
        return (cx1, cy1, cx2 - cx1, cy2 - cy1)

    # Prefer the largest component that ISN'T tucked in a corner. On busy/
    # photographic backgrounds the color-distance method falls back to
    # saliency, which (being a spectral-residual detector) tends to favor
    # small, high-frequency, high-contrast blobs -- and a compact logo badge
    # in a corner is exactly that shape, so left unchecked it can outrank a
    # much larger but lower-frequency hero product/character. A real logo
    # sits in a corner (near an edge on BOTH axes); a hero subject virtually
    # never does, so this is a safe way to keep them apart without needing
    # OCR or any language-specific signal.
    corner_margin = 0.26
    non_corner = []
    for c in comps:
        cx, cy = c["centroid"]
        near_x_edge = cx < w * corner_margin or cx > w * (1 - corner_margin)
        near_y_edge = cy < h * corner_margin or cy > h * (1 - corner_margin)
        if not (near_x_edge and near_y_edge):
            non_corner.append(c)
    pool = non_corner if non_corner else comps
    best = max(pool, key=lambda c: c["area"])
    return best["bbox"]


def refine_alpha_with_grabcut(image_bgr: np.ndarray, bbox) -> np.ndarray:
    """Run GrabCut seeded by bbox to get a soft-ish alpha mask (0-255)
    for the subject, instead of a hard rectangle cutout."""
    h, w = image_bgr.shape[:2]
    x, y, bw, bh = bbox
    pad_x, pad_y = int(bw * 0.06), int(bh * 0.06)
    rect = (max(0, x - pad_x), max(0, y - pad_y),
            min(w - 1, bw + 2 * pad_x), min(h - 1, bh + 2 * pad_y))

    mask = np.zeros((h, w), np.uint8)
    bgd_model = np.zeros((1, 65), np.float64)
    fgd_model = np.zeros((1, 65), np.float64)
    try:
        cv2.grabCut(image_bgr, mask, rect, bgd_model, fgd_model, 5, cv2.GC_INIT_WITH_RECT)
        alpha = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)
    except cv2.error:
        alpha = np.zeros((h, w), np.uint8)
        cv2.rectangle(alpha, (rect[0], rect[1]), (rect[0] + rect[2], rect[1] + rect[3]), 255, -1)

    # If GrabCut collapsed to (near) nothing, fall back to the rect itself.
    if alpha.sum() < 0.15 * 255 * bw * bh:
        alpha = np.zeros((h, w), np.uint8)
        cv2.rectangle(alpha, (x, y), (x + bw, y + bh), 255, -1)

    alpha = cv2.GaussianBlur(alpha, (9, 9), 0)
    return alpha


def _overlap_ratio(box, other):
    x, y, w, h = box
    ox, oy, ow, oh = other
    ix1, iy1 = max(x, ox), max(y, oy)
    ix2, iy2 = min(x + w, ox + ow), min(y + h, oy + oh)
    if ix2 <= ix1 or iy2 <= iy1:
        return 0.0
    inter = (ix2 - ix1) * (iy2 - iy1)
    return inter / float(w * h)


def find_logo_bbox(image_bgr: np.ndarray, subject_bbox, exclude_mask=None,
                    text_boxes=(), corner_margin=0.18):
    """Heuristic logo finder: a small foreground blob sitting near a
    corner that isn't the main subject and isn't just the background
    plate of a text/CTA button (i.e. its box doesn't overlap any OCR'd
    text line -- a real logo mark has no text sitting on top of it,
    while a "SHOP NOW" button does). Returns None if nothing qualifies
    -- logos are optional and many banners simply don't have a
    separable one.
    """
    h, w = image_bgr.shape[:2]
    mask = _foreground_mask(image_bgr, exclude_mask)
    sx, sy, sw, sh = subject_bbox
    mask[sy:sy + sh, sx:sx + sw] = 0

    comps = _components_by_area(mask, min_area_frac=0.0015, max_area_frac=0.05)
    best = None
    for c in comps:
        box = c["bbox"]
        x, y, bw, bh = box
        cx, cy = x + bw / 2, y + bh / 2
        near_edge = (cx < w * corner_margin or cx > w * (1 - corner_margin) or
                     cy < h * corner_margin or cy > h * (1 - corner_margin))
        if not near_edge:
            continue
        if any(_overlap_ratio(box, tb) > 0.1 for tb in text_boxes):
            continue  # looks like a CTA button/text chip, not a logo mark
        aspect = max(bw, bh) / max(1, min(bw, bh))
        if aspect > 1.7:
            continue  # logos are icon-like/compact; wide pills are usually CTA buttons
        if best is None or c["area"] > best["area"]:
            best = c
    return best["bbox"] if best else None
