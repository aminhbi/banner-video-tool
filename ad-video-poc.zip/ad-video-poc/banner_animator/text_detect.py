"""Text detection -- built to work on Persian/Arabic (RTL) banners as
well as Latin ones, even though this environment has no internet
access to fetch Tesseract's Persian language pack (`fas.traineddata`)
or an Arabic-script font.

That's less limiting than it sounds: we never re-typeset or read the
text for meaning -- we only need the pixel bounding box of each text
line so we can crop it as a sprite and animate the *existing* glyphs
the user's banner already has correctly rendered. So:

  1. We still run Tesseract (only the `eng` model is installed), but
     we DO NOT trust its confidence score to decide whether a region
     is real text -- that score is calibrated against an English
     dictionary and can come back low/garbled for Persian glyphs even
     when the bounding box it found is perfectly correct. Instead we
     sanity-check candidate boxes with a script-agnostic "does this
     box actually contain ink, not a flat/blank area" test.
  2. Tesseract's page-segmentation step occasionally refuses to treat
     a region as text at all (it happened even in English, on a
     colored CTA button in testing) and emits nothing for it. As a
     second, fully language-independent pass, we run MSER (a classic
     blob detector) to find letter-shaped connected components and
     group neighbouring ones into line-level boxes -- this needs no
     dictionary or script model, so it works the same for Persian,
     Latin, or anything else.
  3. Lines are ordered for the staggered reveal animation with an
     RTL-aware rule: top-to-bottom across rows (unaffected by reading
     direction), and *right-to-left within a row* by default, since
     that's the natural reveal direction for Persian/Arabic copy.
"""
from dataclasses import dataclass
import numpy as np
import cv2
import pytesseract
from pytesseract import Output


@dataclass
class TextLine:
    x: int
    y: int
    w: int
    h: int
    text: str
    conf: float


def _ink_fraction(image_bgr: np.ndarray, box) -> float:
    """Script-agnostic "is there real ink in here" check: Otsu-threshold
    the crop and return the minority-class fraction. A real line of
    text (any script) typically covers ~5-55% of its box; a blank or
    perfectly flat-colored box collapses to ~0%."""
    x, y, w, h = box
    if w <= 1 or h <= 1:
        return 0.0
    crop = image_bgr[y:y + h, x:x + w]
    if crop.size == 0:
        return 0.0
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    if gray.std() < 3:
        return 0.0  # perfectly flat -- can't be text
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    frac = float(np.mean(binary > 0))
    return min(frac, 1 - frac)


def _lines_from_data(data, image_bgr, min_conf) -> list["TextLine"]:
    groups: dict[tuple, list[int]] = {}
    n = len(data["text"])
    for i in range(n):
        word = data["text"][i].strip()
        try:
            conf = float(data["conf"][i])
        except (TypeError, ValueError):
            conf = -1.0
        if not word or conf < 0:
            continue  # conf < 0 means tesseract didn't even attempt this region
        key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
        groups.setdefault(key, []).append(i)

    lines: list[TextLine] = []
    for key, idxs in groups.items():
        xs1, ys1, xs2, ys2, words, confs = [], [], [], [], [], []
        for i in idxs:
            x, y, w, h = data["left"][i], data["top"][i], data["width"][i], data["height"][i]
            xs1.append(x); ys1.append(y)
            xs2.append(x + w); ys2.append(y + h)
            words.append(data["text"][i])
            confs.append(float(data["conf"][i]))
        x1, y1, x2, y2 = min(xs1), min(ys1), max(xs2), max(ys2)
        pad = max(2, int(0.08 * (y2 - y1)))
        x1, y1 = max(0, x1 - pad), max(0, y1 - pad)
        x2 = min(image_bgr.shape[1], x2 + pad)
        y2 = min(image_bgr.shape[0], y2 + pad)
        box = (x1, y1, x2 - x1, y2 - y1)
        avg_conf = sum(confs) / len(confs)
        # Script-agnostic acceptance: trust high tesseract confidence outright;
        # for anything lower (very possible on non-Latin script glyphs read
        # through the English model), fall back to the ink-density sanity check
        # instead of discarding it.
        if avg_conf < min_conf and _ink_fraction(image_bgr, box) < 0.04:
            continue
        lines.append(TextLine(x=x1, y=y1, w=x2 - x1, h=y2 - y1,
                               text=" ".join(words), conf=avg_conf))
    return lines


def _iou(a, b) -> float:
    ax2, ay2, bx2, by2 = a.x + a.w, a.y + a.h, b.x + b.w, b.y + b.h
    ix1, iy1 = max(a.x, b.x), max(a.y, b.y)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    if ix2 <= ix1 or iy2 <= iy1:
        return 0.0
    inter = (ix2 - ix1) * (iy2 - iy1)
    union = a.w * a.h + b.w * b.h - inter
    return inter / union if union > 0 else 0.0


def _duplicates_existing(cand, existing, iou_thresh=0.25, contain_thresh=0.55) -> bool:
    """True if `cand` overlaps an already-accepted line enough to be a
    duplicate -- either by IoU, or because one box mostly sits inside
    the other (a plain IoU check misses this: a small MSER character
    cluster nested entirely inside an already-accepted Tesseract line
    box has low IoU but is clearly the same text)."""
    for e in existing:
        if _iou(cand, e) > iou_thresh:
            return True
        ax2, ay2, bx2, by2 = cand.x + cand.w, cand.y + cand.h, e.x + e.w, e.y + e.h
        ix1, iy1 = max(cand.x, e.x), max(cand.y, e.y)
        ix2, iy2 = min(ax2, bx2), min(ay2, by2)
        if ix2 <= ix1 or iy2 <= iy1:
            continue
        inter = (ix2 - ix1) * (iy2 - iy1)
        if inter / (cand.w * cand.h) > contain_thresh or inter / (e.w * e.h) > contain_thresh:
            return True
    return False


def _mser_line_boxes(image_bgr: np.ndarray):
    """Fully script-agnostic fallback: find letter-shaped blobs with
    MSER and chain neighbouring ones (similar height, similar vertical
    center, not too far apart horizontally) into line-level boxes.
    Needs no language model at all, so it catches text a Tesseract
    page-segmentation pass refused to recognize as text (this happened
    even for English on a colored CTA button during testing)."""
    h, w = image_bgr.shape[:2]
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    mser = cv2.MSER_create()
    try:
        mser.setMinArea(int(0.00006 * h * w))
        mser.setMaxArea(int(0.02 * h * w))
    except Exception:
        pass
    try:
        _, boxes = mser.detectRegions(gray)
    except cv2.error:
        return []
    if boxes is None or len(boxes) == 0:
        return []

    # character-plausibility filter
    chars = []
    for (x, y, bw, bh) in boxes:
        if bh <= 0 or bw <= 0:
            continue
        aspect = bw / bh
        if not (0.08 <= aspect <= 4.5):
            continue
        if bh < 6 or bh > 0.25 * h:
            continue
        chars.append((x, y, bw, bh))
    if not chars:
        return []

    chars.sort(key=lambda b: (b[1] + b[3] / 2, b[0]))
    used = [False] * len(chars)
    raw_lines = []
    for i, b in enumerate(chars):
        if used[i]:
            continue
        x, y, bw, bh = b
        cy = y + bh / 2
        group = [b]
        used[i] = True
        for j in range(i + 1, len(chars)):
            if used[j]:
                continue
            x2, y2, bw2, bh2 = chars[j]
            cy2 = y2 + bh2 / 2
            if abs(cy2 - cy) < 0.55 * max(bh, bh2) and abs(bh2 - bh) < 0.6 * max(bh, bh2):
                group.append(chars[j])
                used[j] = True
        raw_lines.append(group)

    # split each vertically-aligned group on large horizontal gaps (separate
    # words/lines that merely share a row), and require >=2 chars to count.
    line_boxes = []
    for group in raw_lines:
        group.sort(key=lambda b: b[0])
        median_w = float(np.median([b[2] for b in group]))
        run = [group[0]]
        for prev, cur in zip(group, group[1:]):
            gap = cur[0] - (prev[0] + prev[2])
            if gap > 3.0 * max(median_w, 4):
                if len(run) >= 2:
                    line_boxes.append(run)
                run = [cur]
            else:
                run.append(cur)
        if len(run) >= 2:
            line_boxes.append(run)

    results = []
    for run in line_boxes:
        x1 = min(b[0] for b in run); y1 = min(b[1] for b in run)
        x2 = max(b[0] + b[2] for b in run); y2 = max(b[1] + b[3] for b in run)
        pad = max(2, int(0.1 * (y2 - y1)))
        x1, y1 = max(0, x1 - pad), max(0, y1 - pad)
        x2, y2 = min(w, x2 + pad), min(h, y2 + pad)
        box = (x1, y1, x2 - x1, y2 - y1)
        ink = _ink_fraction(image_bgr, box)
        if 0.03 <= ink <= 0.65:  # real text lines land in this band; solid fills don't
            results.append(box)
    return results


def detect_text_lines(image_bgr: np.ndarray, min_conf: float = 40.0,
                       direction: str = "rtl") -> list[TextLine]:
    """Run OCR (PSM 3 + PSM 11, merged, confidence-lenient) plus an
    MSER script-agnostic fallback pass, and order the resulting lines
    for a staggered reveal: top-to-bottom across rows, then
    right-to-left within a row by default (`direction="ltr"` for
    left-to-right copy), since that matches natural Persian/Arabic
    reading flow.
    """
    rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

    primary = _lines_from_data(pytesseract.image_to_data(rgb, output_type=Output.DICT),
                                image_bgr, min_conf)
    sparse = _lines_from_data(
        pytesseract.image_to_data(rgb, output_type=Output.DICT, config="--psm 11"),
        image_bgr, min_conf)

    lines = list(primary)
    for cand in sparse:
        if not _duplicates_existing(cand, lines):
            lines.append(cand)

    for (x, y, w, h) in _mser_line_boxes(image_bgr):
        cand = TextLine(x=x, y=y, w=w, h=h, text="", conf=-1)
        if not _duplicates_existing(cand, lines):
            lines.append(cand)

    # drop tiny fragments (a handful of stray pixels a couple of px across) unless
    # tesseract itself was quite confident about them
    img_area = image_bgr.shape[0] * image_bgr.shape[1]
    lines = [l for l in lines if l.w * l.h >= 0.0015 * img_area or l.conf >= 60]

    # --- order for staggered reveal: rows top-to-bottom, then RTL/LTR within a row
    rows: list[list[TextLine]] = []
    for l in sorted(lines, key=lambda l: l.y):
        cy = l.y + l.h / 2
        placed = False
        for row in rows:
            r_cy = sum(x.y + x.h / 2 for x in row) / len(row)
            r_h = sum(x.h for x in row) / len(row)
            if abs(cy - r_cy) < 0.6 * r_h:
                row.append(l)
                placed = True
                break
        if not placed:
            rows.append([l])
    rows.sort(key=lambda row: sum(x.y for x in row) / len(row))

    ordered: list[TextLine] = []
    for row in rows:
        ordered.extend(sorted(row, key=lambda l: l.x, reverse=(direction == "rtl")))
    return ordered


def bbox_overlap_frac(line: "TextLine", bbox) -> float:
    """Fraction of `line`'s own area covered by `bbox` (a plain
    (x, y, w, h) tuple). Used to catch OCR hallucinating a "word" on
    top of busy photographic detail (a face, sunglasses, folds of
    clothing) inside the product/subject cutout -- a real failure mode
    observed in testing, distinct from genuine overlaid text."""
    bx, by, bw, bh = bbox
    ix1, iy1 = max(line.x, bx), max(line.y, by)
    ix2, iy2 = min(line.x + line.w, bx + bw), min(line.y + line.h, by + bh)
    if ix2 <= ix1 or iy2 <= iy1:
        return 0.0
    inter = (ix2 - ix1) * (iy2 - iy1)
    area = line.w * line.h
    return inter / area if area > 0 else 0.0


def text_mask(image_shape, lines: list[TextLine]) -> np.ndarray:
    """Binary mask (uint8, 0/255) covering all text line boxes, dilated
    a bit so descenders/anti-aliased edges are fully covered before
    inpainting."""
    mask = np.zeros(image_shape[:2], dtype=np.uint8)
    for l in lines:
        cv2.rectangle(mask, (l.x, l.y), (l.x + l.w, l.y + l.h), 255, -1)
    if mask.any():
        mask = cv2.dilate(mask, np.ones((7, 7), np.uint8), iterations=1)
    return mask
