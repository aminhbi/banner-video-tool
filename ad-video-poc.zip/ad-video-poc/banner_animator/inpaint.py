"""Background plate reconstruction: remove the subject + text + logo
footprints from the original banner and fill the holes so the
background can be panned/zoomed on its own without dragging a
text-shaped or product-shaped ghost along with it.

Two fill strategies:
  1. Global smooth-surface fit. Most ad banners use a flat color, a
     simple linear gradient, or a soft radial vignette/spotlight behind
     the product/text, so we fit a per-channel quadratic surface
     (a + b*u + c*v + d*u^2 + e*v^2 + f*u*v, in normalized coordinates)
     to every unmasked pixel and use it to fill the holes. This avoids
     the "seams converging in the middle" artifact that classical
     inpainting (Telea/NS) produces on large, nearly-uniform regions --
     there's no strong directional texture for it to propagate, and a
     quadratic term is enough to follow a gentle vignette that a plain
     linear fit would visibly mismatch at the edges of a large hole.
  2. cv2.inpaint (Telea) fallback for busier/photographic backgrounds
     where the surface fit is poor (checked via residual error).
"""
import numpy as np
import cv2


def build_removal_mask(image_shape, boxes, dilate=15) -> np.ndarray:
    """boxes: list of (x, y, w, h) rectangles to remove."""
    mask = np.zeros(image_shape[:2], dtype=np.uint8)
    for (x, y, w, h) in boxes:
        cv2.rectangle(mask, (x, y), (x + w, y + h), 255, -1)
    if mask.any() and dilate > 0:
        mask = cv2.dilate(mask, np.ones((dilate, dilate), np.uint8), iterations=1)
    return mask


def _surface_basis(xs, ys, w, h):
    u = xs.astype(np.float64) / w
    v = ys.astype(np.float64) / h
    return np.column_stack([np.ones_like(u), u, v, u * u, v * v, u * v])


def _plane_fill(image_bgr: np.ndarray, mask: np.ndarray, max_rmse=10.0, sample_stride=3,
                 trim_iterations=2, trim_keep_frac=0.75):
    """Fit a per-channel quadratic surface to the unmasked background
    and use it to fill the holes.

    Fit is done jointly across channels with iterative trimming: any
    "background" sample that's actually a stray foreground pixel we
    failed to mask (e.g. a CTA button OCR missed) will have a huge
    residual against the true surface and gets dropped before the next
    fit, so a minority of such contamination doesn't drag the whole
    surface off toward the wrong colors.
    """
    h, w = image_bgr.shape[:2]
    unmasked = mask == 0
    ys, xs = np.where(unmasked[::sample_stride, ::sample_stride])
    ys, xs = ys * sample_stride, xs * sample_stride
    if len(ys) < 400:
        return None

    fill_ys, fill_xs = np.where(mask > 0)
    if len(fill_ys) == 0:
        return image_bgr.copy()

    A = _surface_basis(xs, ys, w, h)
    vals = image_bgr[ys, xs, :].astype(np.float64)  # (N, 3)

    keep = np.ones(len(ys), dtype=bool)
    coef = None
    for _ in range(trim_iterations + 1):
        coef, *_ = np.linalg.lstsq(A[keep], vals[keep], rcond=None)  # (6, 3)
        pred = A @ coef
        resid = np.linalg.norm(pred - vals, axis=1)
        thresh = np.percentile(resid, trim_keep_frac * 100)
        keep = resid <= max(thresh, 1e-6)

    final_rmse = float(np.sqrt(np.mean(np.sum((A[keep] @ coef - vals[keep]) ** 2, axis=1) / 3)))
    if final_rmse > max_rmse:
        return None  # background isn't smooth enough for this to look right

    A_fill = _surface_basis(fill_xs, fill_ys, w, h)
    fill_vals = np.clip(A_fill @ coef, 0, 255)
    result = image_bgr.copy()
    result[fill_ys, fill_xs, :] = fill_vals.astype(np.uint8)
    return result


def inpaint_plate(image_bgr: np.ndarray, mask: np.ndarray) -> np.ndarray:
    if not mask.any():
        return image_bgr.copy()
    plane = _plane_fill(image_bgr, mask)
    if plane is not None:
        return plane
    return cv2.inpaint(image_bgr, mask, inpaintRadius=7, flags=cv2.INPAINT_TELEA)
