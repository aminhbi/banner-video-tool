"""Decompose a flat banner image into an animatable layer stack:

  plate    -- background with subject/text/logo removed & inpainted
  subject  -- RGBA cutout of the product/hero element (near layer)
  texts    -- list of RGBA cutouts, one per OCR'd text line (reading order)
  logo     -- optional RGBA cutout of a small corner mark

Every sprite keeps its original (x, y) position in banner space so the
animator can place it back exactly where it started before applying
per-frame motion.
"""
from dataclasses import dataclass
import numpy as np
import cv2

from .text_detect import detect_text_lines, text_mask, bbox_overlap_frac, TextLine
from .segment import find_subject_bbox, find_logo_bbox, refine_alpha_with_grabcut
from .inpaint import build_removal_mask, inpaint_plate


@dataclass
class Sprite:
    x: int
    y: int
    w: int
    h: int
    rgba: np.ndarray  # (h, w, 4) uint8
    label: str = ""


def _feathered_rect_alpha(h, w, feather=10) -> np.ndarray:
    alpha = np.full((h, w), 255, np.uint8)
    if feather > 0 and h > 2 * feather and w > 2 * feather:
        alpha = cv2.rectangle(np.zeros((h, w), np.uint8), (feather, feather),
                               (w - feather, h - feather), 255, -1)
        alpha = cv2.GaussianBlur(alpha, (feather * 2 + 1, feather * 2 + 1), 0)
    return alpha


def _crop_rgba(image_bgr, alpha_full, box, pad_frac=0.05):
    h, w = image_bgr.shape[:2]
    x, y, bw, bh = box
    px, py = int(bw * pad_frac), int(bh * pad_frac)
    x1, y1 = max(0, x - px), max(0, y - py)
    x2, y2 = min(w, x + bw + px), min(h, y + bh + py)
    crop = image_bgr[y1:y2, x1:x2]
    a = alpha_full[y1:y2, x1:x2]
    rgba = np.dstack([crop, a])
    return Sprite(x=x1, y=y1, w=x2 - x1, h=y2 - y1, rgba=rgba)


def build_layers(banner_bgr: np.ndarray, min_conf: float = 40.0, direction: str = "rtl"):
    h, w = banner_bgr.shape[:2]

    lines: list[TextLine] = detect_text_lines(banner_bgr, min_conf=min_conf, direction=direction)
    t_mask = text_mask(banner_bgr.shape, lines)

    # Pass 1: a rough subject guess, used only to catch a known OCR failure
    # mode -- Tesseract occasionally "reads" a short garbled word out of busy
    # photographic detail (a face, sunglasses, fabric folds) inside the
    # product/hero cutout. That's not real overlaid text, so any low/medium
    # confidence line sitting mostly inside the rough subject box gets pruned
    # before we commit to a final subject box and text-sprite list.
    rough_subject_bbox = find_subject_bbox(banner_bgr, exclude_mask=t_mask)
    lines = [l for l in lines
             if not (l.conf < 60 and bbox_overlap_frac(l, rough_subject_bbox) > 0.5)]
    t_mask = text_mask(banner_bgr.shape, lines)

    subject_bbox = find_subject_bbox(banner_bgr, exclude_mask=t_mask)
    text_boxes = [(l.x, l.y, l.w, l.h) for l in lines]
    logo_bbox = find_logo_bbox(banner_bgr, subject_bbox, exclude_mask=t_mask, text_boxes=text_boxes)

    subject_alpha_full = refine_alpha_with_grabcut(banner_bgr, subject_bbox)
    subject_sprite = _crop_rgba(banner_bgr, subject_alpha_full, subject_bbox)
    subject_sprite.label = "subject"

    logo_sprite = None
    if logo_bbox is not None:
        lx, ly, lw, lh = logo_bbox
        logo_alpha_full = np.zeros((h, w), np.uint8)
        logo_alpha_full[ly:ly + lh, lx:lx + lw] = _feathered_rect_alpha(lh, lw, feather=4)
        logo_sprite = _crop_rgba(banner_bgr, logo_alpha_full, logo_bbox, pad_frac=0.15)
        logo_sprite.label = "logo"

    text_sprites = []
    for line in lines:
        line_alpha_full = np.zeros((h, w), np.uint8)
        line_alpha_full[line.y:line.y + line.h, line.x:line.x + line.w] = \
            _feathered_rect_alpha(line.h, line.w, feather=max(3, line.h // 8))
        sprite = _crop_rgba(banner_bgr, line_alpha_full, (line.x, line.y, line.w, line.h), pad_frac=0.1)
        sprite.label = line.text
        text_sprites.append(sprite)

    removal_boxes = [subject_bbox]
    if logo_bbox is not None:
        removal_boxes.append(logo_bbox)
    removal_boxes += [(l.x, l.y, l.w, l.h) for l in lines]
    removal_mask = build_removal_mask(banner_bgr.shape, removal_boxes, dilate=15)
    plate = inpaint_plate(banner_bgr, removal_mask)

    return {
        "size": (w, h),
        "plate": plate,
        "subject": subject_sprite,
        "logo": logo_sprite,
        "texts": text_sprites,
    }
